function [] = graphcreator(data)

Sim_data=data;
time = Sim_data(:,1);
signals = Sim_data(:,2:end);

% Plot signal
graph =[];
Umultiplier = 10*0.03

graph(1)=  plot(time, Umultiplier * ones(size(time)),'Color', 'k');
hold on
graph(2) = plot(time, signals(:,1), 'Color', 'b');
graph(3) = plot(time, signals(:,2), 'LineStyle','--', 'Color', 'r');
graph(4) = plot(time, signals(:,3), 'LineStyle',':', 'Color', 'c');
hold off
grid on
description= '\psi(t)\_';
titlee='Odezva \psi na jednotkov� skok';


% Lines width in the graph
set(graph(:),'LineWidth',3);
% Change the hiearchy of ploted lines
%uistack(graph(1), 'bottom')
% Font size of the legend
set(gca,'FontSize',15);
% Signals description and position of the legend
legend(graph ,{strcat(num2str(Umultiplier),'* input'), strcat(description,'orig'),strcat(description,'lin'),strcat(description,'nolin') },'Location','SouthEast');

% Axes description
xlabel('Time t[s]','FontSize',15);
ylabel('\psi [rad]','FontSize',15);
title(titlee);

% Do this only if you want to change the implicit limits
x_plot_limits = [0 10];
y_plot_limits = [0 10*0.09];

xlim(x_plot_limits);
ylim(y_plot_limits);

% Turn on the grid
grid on; 


%% Export to files
file = 'file_to_export'
% srt dimensipon for a PDF export
set(gcf, 'PaperUnits', 'centimeters ',  'OuterPosition', [150, 50, 1300, 850], 'PaperType', 'A4', 'PaperOrientation', 'landscape');
set(gcf,'Position', [200,100,1200,800]);
%set landscape figure for pdf export
set(gcf,'PaperPositionMode','Auto', 'PaperOrientation', 'Landscape')
%save pdf
%print(gcf, '-dpdf', strcat(file, '.pdf'), '-r0');
%save eps
print(gcf, '-depsc2', strcat(file, '.eps'));
%save png
%han = getframe(gcf);
%imwrite(han.cdata, strcat(file, '.png'));