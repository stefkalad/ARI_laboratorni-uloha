
%zadani
syms s h1 dh1   u un h1off vt h2 dh2 v_o h2off
%dr1=(su* sign(kc*(u-un)^2-p*g*(h1+h1off) ) * sqrt(2/p * abs(kc*(u-un)^2-p*g*(h1+h1off)))-vt*st*sign(h1-h2)*sqrt(2*g*abs(h1-h2)))/s
%dr2=(-vt*st*sign(h1-h2)*sqrt(2*g*abs(h1-h2))-v_o*s0*sqrt(2*g*(h2+h2off)))/s
syms stS s0S suS k 
dr11=(suS* sign(k*(u-un)^2-(h1+h1off) ) * sqrt(abs(k*(u-un)^2-(h1+h1off))) - vt*stS*sign(h1-h2)*sqrt(abs(h1-h2)))- dh1 ==0
dr22=(vt*stS*sign(h1-h2)*sqrt(abs(h1-h2))-v_o*s0S*sqrt((h2+h2off))) - dh2 ==0
dr1=(suS* sign(k*(u-un)^2-(h1+h1off) ) * sqrt(abs(k*(u-un)^2-(h1+h1off)))   -vt*stS*sign(h1-h2)*sqrt(abs(h1-h2)))
dr2=(vt*stS*sign(h1-h2)*sqrt(abs(h1-h2))          -v_o*s0S*sqrt((h2+h2off)))
% h1off = 0.053582
% un = 1
% k=32801049151629025/(144115188075855872*25)R = 32801049151629025/(144115188075855872*25)

%%
% reseni konstant
h1offf=0.053582
h2offf= -0.000007847
unn = 1
%0.053582  0.0562456
promene={'s','h1','dh1',   'u','un','vt','h2','dh2','v_o','h2off','h1off','k'}
hodnoty={'s',0.17437996,0,6,     unn,      0,     0,      0,     0,0,    h1offf,'k'}
rov1=subs(dr11,{'h1','dh1','vt','u','h1off','un','k'},{0.1740210,0,0,6,0.053582,1,'k'})
K = solve(rov1,k)



promene={'s','h1','dh1','su','u','un','g','p','vt','st','h2','dh2','v_o','s0','h2off','h1off','k'}
hodnoty={'s',0.2635,0.479,'su',10, unn','g','p',   0,'st','h2','dh2',  0,  's0',       h2offf,     h1offf,K}
promene={'s','h1','dh1','su','u','un','g','p','vt','st','h2','dh2','v_o','s0','h2off','h1off','k'}
hodnoty={'s',0.3117,0.1784,'su',8, unn,'g','p',   0,'st','h2','dh2',  0,  's0',       h2offf,    h1offf,K}
rov2=subs(dr11,promene,hodnoty)
susS = solve(rov2,suS)
% 0.627531815807612267979884


promene={'h1','dh1', 'u' ,'un','vt','h2','dh2','v_o','h2off','h1off','k','suS'}
hodnoty={0.6504,  0,    10,  unn,0.6,0.3341,0.03768,0  ,      0,h1offf,K,susS}
promene={'h1','dh1', 'u' ,'un','vt','h2','dh2','v_o','h2off','h1off','k'}
hodnoty={0.3903,  0,    8,    unn,0.6,0.2122,0.033911,0,h2offf,h1offf,K}
promene={'h1','dh1', 'u' ,'un','vt','h2','dh2','v_o','h2off','h1off','k'}
hodnoty={0.2731,  0,    7,    unn,0.5,0.1345,0.02494,0,h2offf,h1offf,K}
promene={'h1','dh1', 'u' ,'un','vt','h2','dh2','v_o','h2off','h1off','k'}
hodnoty={0.3843,  0,    8,    unn,0.9,0.1678,0.05695,0,h2offf,h1offf,K}

rov4=subs(dr22,promene,hodnoty)
stsS = solve(rov4,stS)


promene={'h1','dh1',    'u',    'un','vt','h2','dh2',  'v_o','h2off','h1off','k'}
hodnoty={0.2723,0.0005060,7,      unn, 0.5 ,0.06603,0.007233,0.5,    h2offf,  h1offf,'k'}
promene={'h1','dh1',    'u',    'un','vt','h2','dh2',  'v_o','h2off','h1off','k'}
hodnoty={0.3904,0,      8,      unn,     0.5 ,0.138655,0  ,0.5,    h2offf,  h1offf,K}
promene={'h1','dh1',    'u',    'un','vt','h2','dh2',  'v_o','h2off','h1off','k','suS','stS'}
hodnoty={0.6504,0,      10,      unn,     0.5 ,0.2304,0  ,0.5,    h2offf,  h1offf,K,susS,stsS}
rov6=subs(dr22,promene,hodnoty)
sosS = solve(rov6,s0S)


%%
% neline�rn� model
promene={'u',      'vt', 'v_o','h1','h2',          'un','h2off','h1off','k','suS','s0S','stS'}
hodnoty={'u(1)','u(2)','u(3)','u(4)','u(5)',        unn ,     h2offf ,h1offf,K,susS,sosS,stsS}
func1=subs(dr1,promene,hodnoty)
func2=subs(dr2,promene,hodnoty)

%%
%linearizvan�
syms x1 x2 
eq1 = subs(dr1,{'h1','h2'},{'x1','x2'})
eq2 = subs(dr2,{'h1','h2'},{'x1','x2'})


As=jacobian([eq1,eq2],[x1,x2])
Bs=jacobian([eq1,eq2],[u,vt,v_o])
Cs=[1 0];
Ds=[0 0 0];
promene={'u', 'vt', 'v_o','x1','x2',          'un','h2off','h1off','k','suS','s0S','stS'}
hodnoty={7,   0.5,  0.5,0.2727, 0.09674,        unn,h2offf, h1offf,K,susS,sosS,stsS}
latex(As)

A=subs(As,promene,hodnoty)
B=subs(Bs,promene,hodnoty)
Aa=double(A)
Bb=double(B)
Cc=double(Cs)
Cc2=double([0 1])
Dd=double(Ds)
eig(Aa)
vodarnaa=ss(Aa,Bb,Cc,Dd)

%{
figure(1)
step(vodarnaa(1,2),5)
bode(vodarnaa)
%}
