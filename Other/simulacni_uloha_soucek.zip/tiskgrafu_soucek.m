figure(1)
graph = plot(ScopeData1h1.time,ScopeData1h1.signals.values,'r','LineWidth',2);
hold on

graph = plot(ScopeData2h1.time,ScopeData2h1.signals.values,'--b');
set(graph,'LineWidth',2);

graph = plot(ScopeData3h1.time,ScopeData3h1.signals.values,'g');
set(graph,'LineWidth',2);


grid on
legend('h_1 p�vodn� model','h_1 neline�rn� model','h_1 linearizovan� model','Location','southeast')
xlabel('t [s]','FontSize',13)
ylabel('h(t) [cm]','FontSize',13)

title ('Odezva hladiny h_1 na vstupy')
hold off


figure(2)
graph = plot(ScopeData1h2.time,ScopeData1h2.signals.values,'r');
set(graph,'LineWidth',2);
hold on
graph = plot(ScopeData2h2.time,ScopeData2h2.signals.values,'--b');
set(graph,'LineWidth',2);
graph = plot(ScopeData3h2.time,ScopeData3h2.signals.values,'g');
set(graph,'LineWidth',2);
legend('h_2 p�vodn� model','h_2 neline�rn� model','h_2 linearizovan� model','Location','southeast')

%title ('Odezva na skok u(t) = 1')
%title ('Odezva syst�mu na jednotkov� skok')
xlabel('t [s]','FontSize',13)
ylabel('h(t) [cm]','FontSize',13)
grid on
title ('Odezva hladiny h_2 na vstupy')
hold off